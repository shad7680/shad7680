# Online Resume Generator

[Click here to visit the app](https://resume-processor.netlify.app/)

[![Netlify Status](https://api.netlify.com/api/v1/badges/d2c2ac88-ef5a-433b-984e-c6ea4bf143e1/deploy-status)](https://app.netlify.com/sites/resume-processor/deploys)
